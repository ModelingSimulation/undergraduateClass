%sphere.m   main program
nref=3; %level of refinement
nvmax=12*4^nref; %number of 
ntmax=20*4^nref;%
x=zeros(nvmax,3);
v=zeros(ntmax,3);
dodec
for nr=1:nref
  refine
  triplot
end

x=x(1:nv,:);
